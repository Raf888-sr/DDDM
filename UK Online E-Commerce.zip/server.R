

server <- function(input,output) {
  
  
  dataset <- reactive({
    tbl <- input$file
    ext <- tools::file_ext(tbl$datapath)
    
    req(tbl)
    validate(need(ext == "csv", "Please upload a csv file"))
    
    read.csv(tbl$datapath)
                          })
  newdata <- reactive({
    df <- dataset()
    
    df <- df[complete.cases(df),]
   
    df$Date <- date(df$InvoiceDate)
    df$Year <- year(df$InvoiceDate)
    df$Month <- month(df$InvoiceDate, label = TRUE)
    df$Day <- weekdays(as.Date(df$InvoiceDate))
    df$Day <- factor(df$Day, levels= c("Sunday", "Monday",
                                       "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"))
    df$Hour <- hour(df$InvoiceDate)
    df$MonthYear <- paste(df$Year,'-',df$Month)
    df$Season <- time2season(df$Date,out.fmt = "seasons")
    df$Description <- as.factor(df$Description)
    df$Country <- as.factor(df$Country)
    df$Revenue <- df$UnitPrice * df$Quantity
    return(df)
    
  })
  
 trend_df <- reactive({
   df_time <- newdata() %>% 
     group_by(YrMonth =factor(newdata()$MonthYear,levels = unique(newdata()$MonthYear))) %>%
     summarise(Revenue = sum(Revenue))
   return(df_time)})
 
 country_df <- reactive({
   df_country <- newdata() %>% 
     group_by(Country) %>%
     summarise(Revenue = sum(Revenue))
     return(df_country)
 })
 
 most_ordered_df <-reactive({
   df_orders <- newdata() %>% 
     group_by(Description) %>% 
     dplyr::summarise(n=n()) %>% 
     top_n(10,n) %>% 
     arrange(desc(n))
   return(df_orders)
 })
 
 first_in_order <- reactive({
   first_in_order <- newdata()[order(newdata()$InvoiceNo, newdata()$InvoiceDate , decreasing=TRUE),]
   occurrenceClean <- first_in_order[!duplicated(first_in_order$InvoiceNo),]
   occurrenceClean <-occurrenceClean %>% group_by(Description) %>% summarise(number = n()) %>% top_n(10,number) %>% arrange(desc(number))
   return(occurrenceClean)
 })
 
 transaction_df <- reactive({
   if(input$season == "Whole Year"){
     data <- newdata()}
   else{
     data <- newdata() %>% 
       filter(Season == input$season)
   }
   transactionData <- ddply(data,c("InvoiceNo","Date"),
                            function(df1)paste(df1$Description,
                                               collapse = ","))
   #set column InvoiceNo of dataframe transactionData  
   transactionData$InvoiceNo <- NULL
   #set column Date of dataframe transactionData
   transactionData$Date <- NULL
   #Rename column to items
   colnames(transactionData) <- c("items")

   write.csv(transactionData,"market_basket_transactions.csv", quote = FALSE, row.names = FALSE)
   tr <- read.transactions('market_basket_transactions.csv', format = 'basket', sep=',')

   return(tr)
 })
 
rules <- reactive({
  apriori(transaction_df(), parameter = list(supp=0.001,
                                                    conf=as.numeric(input$confidence),
                                                    maxlen = input$maxlen))
})

# rules <- apriori(transaction_df(),parameter = list(supp=0.001, conf=0.8,maxlen=10))
subRules<-reactive({
  x <- rules()
  subRules<-x[quality(x)$confidence>as.numeric(input$confidence)]
  })


  output$dataT <- DT::renderDT(newdata(),extensions = c("Buttons"), 
                               options = list(dom = 'Bfrtip',
                                              buttons = c('copy', 'csv', 'excel', 'pdf', 'print')
                               ))
  
  output$structure <- renderPrint({
    newdata() %>% 
      str()
  })
  

  output$total_revenues <- renderValueBox({
    valueBox(prettyNum(sum(newdata()$Revenue),big.mark = ","),
             "Total Sales",
             icon=icon("pound-sign"),
             subtitle = "Pounds",
             color = "fuchsia")
  })
  
  output$customers <- renderValueBox({
    valueBox(prettyNum(length(unique(newdata()$CustomerID)),big.mark = ","),
             icon=icon("user"),
             subtitle = "Customers",
             color = "purple")
  })
  
  output$orders <- renderValueBox({
    valueBox(prettyNum(length(unique(newdata()$InvoiceNo)),big.mark = ","),
             icon=icon("fa-regular fa-clipboard-list"),
             subtitle = "Orders",
             color = "red")
  })
  
  output$time <- renderHighchart({

    trend_df() %>% 
      hchart('line',
             hcaes( x = YrMonth, y = Revenue)) %>% 
      hc_title(text = "When was our customers' activity the highest?", align = "left",margin = 50, style = list(fontSize = 18, fontFamily = "Lucida Grande" , fontWeight = "bold")) %>% 
      hc_subtitle(text = "Most customers order during fall and winter. November 2011 recorded the highest revenues generated.",
                   align = "left",
                   margin = 30,
                   style = list(fontsize = 12, fontFamily = "Lucida Grande", fontWeight = "italic"))
  })
  
  output$map <- renderLeaflet({
    
    
    df_country <- newdata() %>% 
      group_by(Country) %>%
      summarise(Revenue = sum(Revenue))
    
    sPDF <- joinCountryData2Map(df_country
                                ,joinCode = "NAME"
                                ,nameJoinColumn = "Country", verbose = TRUE)
    
    # single out world countries with revenue (revenue did not come from all world countries)
    existing_countries <- subset(sPDF, !is.na(Revenue))
    
    # create bins for revenue amounts, for coloring
    bins <- c(0, 50000, 100000, 150000, 200000, 250000, 300000, Inf)
    pal <- colorBin("BrBG", domain = existing_countries$Revenue, bins = bins)
    
    # create popup labels with exact revenue amount for every country
    labels <- paste0("<strong>", existing_countries$Country, "</strong><br/>", 
                     format(existing_countries$Revenue, digits = 0, big.mark = ".", decimal.mark = ",", scientific = FALSE),
                     " GBP") %>% lapply(htmltools::HTML)
    
    # draw the world map with overlayed revenue per country
    leaflet(existing_countries) %>%
      addTiles() %>%  # Add default OpenStreetMap map tiles
      addPolygons(
        fillColor = ~pal(Revenue),
        weight = 1,
        opacity = 1,
        color = "white",
        dashArray = "3",
        fillOpacity = 0.7,
        highlight = highlightOptions(
          weight = 2,
          color = "#666",
          dashArray = "",
          fillOpacity = 0.7,
          bringToFront = TRUE),
        label = labels,
        labelOptions = labelOptions(
          style = list("font-weight" = "normal", padding = "3px 8px"),
          textsize = "15px",
          direction = "auto")) %>% 
      leaflet::addLegend(pal = pal, values = ~Revenue, opacity = 0.7, title = NULL, position = "topright") %>%
      setView(17,34,3)
  })

  
  output$popular_hour <- renderHighchart({
    s <- count(newdata()$Hour)
    time_before <- s[which.max(s$freq)-1,1]
    time_after <- s[which.max(s$freq)+2,1]
    count(newdata()$Hour) %>% 
      
    
      hchart('column', hcaes(x = 'x', y = 'freq'), color = "#502765") %>%
      hc_title(text = "What time of day do customers order the most?", align = "left",margin = 50, style = list(fontSize = 18, fontFamily = "Lucida Grande" , fontWeight = "bold"))%>%
      hc_subtitle(text = paste("Most customers order between",ifelse(time_before >= 12, paste(time_before%%12, "PM"),paste(time_before,"AM"))
                               ,"and",
                               ifelse(time_after >= 12, paste(time_after%%12, "PM"),paste(time_after,"AM"))),
                  align = "left",
                  margin = 30,
                  style = list(fontsize = 12, fontFamily = "Lucida Grande", fontWeight = "italic")) %>%
      hc_xAxis(title = "Hour") %>%
      hc_yAxis(title = list(text="Number of Orders")) %>%
      hc_tooltip(pointFormat = " Count: {point.y} <br>")

  })
  
  output$popular_day<- renderHighchart({
    day <- count(newdata()$Day)
    popular_day <- day[which.max(day$freq),1]
    
    count(newdata()$Day) %>% 
      hchart('column', hcaes(x = 'x', y = 'freq'), color = "#da3896") %>% 
      hc_title(text = "What day of week do customers order the most?", align = "left",margin = 50, style = list(fontSize = 18, fontFamily = "Lucida Grande" , fontWeight = "bold")) %>% 
      hc_subtitle(text = paste(popular_day,"is the most popular day for ordering"),
                  align = "left",
                  margin = 30,
                  style = list(fontsize = 12, fontFamily = "Lucida Grande", fontWeight = "italic")) %>% 
      hc_xAxis(title = "Day") %>% 
      hc_yAxis(title = list(text="Number of Orders")) %>%
      hc_tooltip(pointFormat = " Count: {point.y} <br>")
    
  })
  
  output$most_ordered<- renderHighchart({
    
    popular_items <- most_ordered_df() %>% 
      hchart('bar', hcaes(x = Description, y = n), color = "#d20931") %>% 
      hc_xAxis(title = "Day") %>% 
      hc_yAxis(title = list(text="Count"))

    
    
    })
  
  
  output$best_selling<- renderHighchart({
    
    revenue_per_item <- newdata() %>% 
      group_by(Description) %>% 
      dplyr::summarise(n=sum(Revenue)) %>% 
      top_n(10,n) %>%
      arrange(desc(n))
    
    best_selling<- revenue_per_item %>% 
      hchart('bar', hcaes(x = Description, y = n), color = "#d20931") %>% 
      hc_subtitle(text = paste(revenue_per_item$Description[1], "is the most selling product. The chart shows that not all our most ordered products geerated most revenue."),
                  align = "left",
                  margin = 30,
                  style = list(fontsize = 12, fontFamily = "Lucida Grande", fontWeight = "italic")) %>% 
      hc_xAxis(title = "Day", minorGridLineWidth = 0) %>% 
      hc_yAxis(title = list(text="Sales (GBP)"), minorGridLineWidth = 0)
  })
  
  output$first_item <- renderHighchart({
    first_in_order <- newdata()[order(newdata()$InvoiceNo, newdata()$InvoiceDate , decreasing=TRUE),]
    occurrenceClean <- first_in_order[!duplicated(first_in_order$InvoiceNo),]
    occurrenceClean <-occurrenceClean %>% group_by(Description) %>% summarise(number = n()) %>% top_n(10,number) %>% arrange(desc(number))
    occurrenceClean %>% 
      hchart('bar',hcaes(x = Description, y = number), color = "#0a636b") %>% 
      hc_xAxis(title = "Description") %>% 
      hc_yAxis(title = list(text="Count)"), minorGridLineWidth = 0)
      
  })
  
  output$Nvalues <- renderUI({
      numericInput("topNvalues",
                   "Top N values",
                   10,
                   min = 1,
                   max = 20)
  })
  
  
  output$arulesTable <- DT::renderDT({
                                                  
    top_df <- DATAFRAME(rules()[1:input$topValues])
  

  })
  
  output$scatter <- plotly::renderPlotly({
    plot(subRules())
  })

  output$network <-visNetwork::renderVisNetwork({
 
    subrules <- head(rules(), n = input$topValues, by = "confidence")
    df_rules <- DATAFRAME(subrules) %>% rowid_to_column("rules") %>% mutate(rules = paste("Rules",
                                                                                          rules),
                                                                            RHS = str_remove_all(string = RHS, pattern = "[{}]"))
    df_items <- df_rules %>% mutate(LHS = str_remove_all(string = LHS, pattern = "[{}]")) %>%
      separate(col = LHS, into = c(paste0("item_", 1:3)), sep = ",") %>%
      pivot_longer(cols = c(item_1, item_2, item_3),  names_to = "antecedent", values_to = "item") %>%
      select(rules, antecedent, item, RHS, everything()) %>%
      filter(is.na(item) == F)
    
    nodes <- data.frame(name = unique(c(df_items$item, df_items$RHS, df_items$rules))) %>%
      rowid_to_column("id") %>% mutate(group = ifelse(str_detect(name, "Rules"), "A",  "B"), label = name, value = c(rep(NA, n_distinct(c(df_items$item, df_items$RHS))),
                                                                                                                     df_rules$lift), support = c(rep(NA, n_distinct(c(df_items$item, df_items$RHS))),
                                                                                                                                                 df_rules$support), confidence = c(rep(NA, n_distinct(c(df_items$item, df_items$RHS))),
                                                                                                                                                                                   df_rules$confidence), shape = ifelse(group == "A", "circle", "box"), color = ifelse(group == "A", "lightblue", "lightgreen"), title = ifelse(test = group == "A", yes = paste(name, "<br> Lift:", round(value, 2), "<br> Confidence:", round(confidence, 2),"<br> Support:", round(support, 2)), no = as.character(name)))
    
    
 
    edges <- data.frame(from = df_items$item, to = df_items$rules) %>%
      bind_rows(data.frame(from = df_rules$rules, to = df_rules$RHS)) %>%
      left_join(nodes, by = c(from = "name")) %>% select(id, to) %>%
      rename(from = id) %>%
      left_join(nodes, by = c(to = "name")) %>%
      select(from, id) %>% rename(to = id) %>% mutate(color = ifelse(to <= 33, "red", "lightgreen"))

  visNetwork(nodes = nodes, edges = edges, height = "500px", width = "100%") %>% visEdges(arrows = "to") %>%
    visOptions(highlightNearest = T) %>%
    visInteraction(tooltipStyle = "position: fixed; visibility: hidden; padding: 5px; white-space: nowrap;
  font-size: 18px; color: black; background-color: white; border-color: orange")
 })

  output$textrule <- renderText({
    
    df_text <- c()
    top_df <- DATAFRAME(rules())
    x <- top_df %>% filter(confidence == 1)
    
    paste("<p>During the",strong(input$season),":<br>",
          "<p>People who usually buy",strong(x$LHS[1]),"also buy",strong(x$RHS[1]),"<br><br> People who usually buy",strong(x$LHS[2]),"also buy",strong(x$RHS[2]),
          "<br><br>People who usually buy",strong(x$LHS[3]),"also buy",strong(x$RHS[3]),
          "<br><br>People who usually buy",strong(x$LHS[4]),"also buy",strong(x$RHS[4]),
          "<br><br>People who usually buy",strong(x$LHS[5]),"also buy",strong(x$RHS[5]),"</p>")
    

    
    
    
  })
  

}
