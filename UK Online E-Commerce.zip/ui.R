
# Set a custom them for the dashboard
mytheme <- create_theme(
  adminlte_color(
    light_blue = "#331940"
  ),
  adminlte_sidebar(
    dark_bg = "#331940",
    dark_hover_bg = "#331940"
  )
)

header <-  dashboardHeader(title = "UK Online Retail")

sidebar <- dashboardSidebar(tags$style(".well {background-color:[#f9fafb];}"),
                            sidebarMenu(id = "sidebar",
                       menuItem(
                                fileInput("file",
                                          "Upload a CSV file",
                                          accept = ".csv")
                              ),
                       menuItem(
                               "Dataset",
                               tabName = "data",
                               icon = icon("table")),
                       menuItem(
                              "Descriptive Analysis",
                              icon = icon("poll"),
                              menuSubItem(
                                          "Overview",
                                          tabName = "overview"),
                              menuSubItem(
                                "Popular Order Time",
                                tabName = "popular_time"),
                              menuSubItem(
                                "Purchasing Behavior",
                                tabName = "behavior")
                              
                       ),
                       menuItem(
                         "Prescriptive Analysis",
                         icon = icon("brain"),
                         tabName = "prescriptive")))



body <- dashboardBody(
                  use_theme(mytheme),
                    tabItems(
                      ## First tab item
                      tabItem(tabName = "data",
                              tabBox(id = "t1",
                                     width = 12,
                                     tabPanel("About",
                                              icon = icon("info-circle"),
                                              fluidRow(
                                                column(width = 6,
                                                       tags$img(src ='https://raw.githubusercontent.com/Raf888-sr/DDDM/main/ecommerce.png',width =300 , height = 300, style="display: block; margin-left: auto; margin-right: auto;")),
                                                column(width = 6,
                                                       h2("Online Retail Data-Driven App"),
                                                       p("The app is showing some of the inisghts of an Online Gift Shop based in the United Kingdom. The data contains
                                                         more than 400k records of each product ordered in the UK and overseas. The main purpose of this app is to find relationships between
                                                         products and how internal stakeholders can cross-sell or up-sell products during each season."),
                                                       p("Source:",a(href = "https://archive.ics.uci.edu/ml/index.php", "UCI Machine Learning Repository"))))),
        
                                     tabPanel("Data",
                                              icon = icon("th"),
                                              fluidRow(
                                                column(width = 12,
                                                       DT::DTOutput("dataT"))
                                              )),
                                      tabPanel("Structure",
                                               verbatimTextOutput("structure"),
                                               icon = icon("uncharted")))),
                      ## Second Tab item
                      tabItem(tabName = "overview",
                              fluidRow(
                                # KPIs
                                # uiOutput("dates"),
                                column(width = 12,height = 12,
                                valueBoxOutput("total_revenues"),
                                valueBoxOutput("customers"),
                                valueBoxOutput("orders"))),
                                fluidRow(
                                  column(width = 12,
                                       box(
                                       title = h4("Sales Trend",style = 'font-size:18px;font-weight:bold;'),
                                       highcharter::highchartOutput("time",height="800px"),
                                       collapsible = TRUE , 
                                       collapsed = T,
                                       solidHeader = FALSE,
                                       status = "primary"),
                                       box(
                                         title = h4("Sales Per Country",style = 'font-size:18px;font-weight:bold;'),
                                         leafletOutput("map",height="800px"),
                                         collapsible = TRUE , 
                                         collapsed = T,
                                         solidHeader = FALSE,
                                         status = "primary")))),
                              # column(width = 6,
                              #          leafletOutput("map",height="800px"))),
                      ## Third Tab item
                      tabItem(tabName = "popular_time",
                              fluidRow(
                                  box(
                                    title = h4("Popular Order Times",style = 'font-size:18px;font-weight:bold;'),
                                    highcharter::highchartOutput("popular_hour",height="800px"), 
                                    collapsible = TRUE , 
                                    collapsed = T,
                                    solidHeader = FALSE,
                                    status = "primary"),
                                  box(
                                    title = h4("Popular Order Days", style = 'font-size:18px;font-weight:bold;'),
                                    highcharter::highchartOutput("popular_day",height="800px"), 
                                    collapsible = TRUE , 
                                    collapsed = T,
                                    solidHeader = FALSE,
                                    status = "primary"))),
                                  # column(width = 6,
                                  #        highcharter::highchartOutput("popular_day",height="800px"))),
                      ## Fourth Tab Item
                      tabItem(tabName = "behavior",
                              fluidRow(
                                box(
                                  title = h4("Most Orderd Items", style = 'font-size:18px;font-weight:bold;'),
                                  highcharter::highchartOutput("most_ordered",height="400px"), 
                                  collapsible = TRUE , 
                                  collapsed = T,
                                  status = "primary",
                                  solidHeader = FALSE),
                              box(
                                title = h4("Best Selling Items", style = 'font-size:18px;font-weight:bold;'),
                                highcharter::highchartOutput("best_selling",height="400px"), 
                                collapsible = TRUE , 
                                collapsed = T,
                                status = "primary",
                                solidHeader = FALSE)),
                              fluidRow(
                                box(
                                  title = h4("First Item In Order", style = 'font-size:18px;font-weight:bold;'),
                                  highcharter::highchartOutput("first_item",height="400px"), 
                                  collapsible = TRUE , 
                                  collapsed = T,
                                  status = "primary",
                                  solidHeader = FALSE)
                              )),
              
                      
                      ## Fifth Tab
                      tabItem(tabName = "prescriptive",
                             box(height="150px", width = 12,
                              fluidRow(
                               column(3,
                                sliderInput("topValues",
                                          "Top N Rules:",
                                          min = 5,
                                          max = 100,
                                          step = 5,
                                          value = 10)),
                              # uiOutput("category"),
                              # sliderInput("support",
                              #             "Support:",
                              #             min = 0.0,
                              #             max = 0.1,
                              #             step = 0.0099,
                              #             value = 0.001),
                              column(3,
                                     sliderInput("confidence",
                                          "Confidence:",
                                          min = 0.0,
                                          max = 1.0,
                                          step = 0.1,
                                          value = 0.25)),
                              column(3,
                                     sliderInput("maxlen",
                                          "Max Items Per Set:",
                                          min = 2,
                                          max = 10,
                                          step = 1,
                                          value = 2)),
                              column(3,
                                     selectInput("season",
                                                 "Choose a season:",
                                                 choices = c("Whole Year","autumm","winter","spring","summer"))))),
                              
                              # uiOutput("confidence"),
                              # uiOutput("max_items"),
                              tabBox(id = "t2",
                                     width = 25,
                                     tabPanel("Association Rules",
                                              icon = icon("info-circle"),
                                              fluidRow(
                                                column(width = 12,
                                                       DT::DTOutput ("arulesTable")))),
                                     tabPanel("Association Rules Scatterplot",
                                              icon = icon("scatterplot"),
                                              plotly::plotlyOutput("scatter")),
                                     tabPanel("Network Graph",
                                              icon = icon("project-diagram"),
                                              visNetworkOutput("network", height = "600px")),
                                     tabPanel("Marketing Insights",
                                              icon = icon("lightbulb"),
                                              htmlOutput("textrule"))))))
                   
# ## First tab item
# tabItem(tabName = "data",
#         tabBox(id = "t1",
#                width = 25,
#                tabPanel("About",
#                         icon = icon("info-circle"),
#                         fluidRow(
#                           column(width = 12,
#                                  DT::DTOutput("dataT"))
#                         ),
#                         fluidRow(
#                           column(width =12,tags$br(),
#                                  textOutput("dimension")
#                           ))),
#                tabPanel("Structure",
#                         verbatimTextOutput("structure"),
#                         icon = icon("uncharted")))),

                 


ui <- dashboardPage( header = header,
                    sidebar = sidebar,
                    body = body)